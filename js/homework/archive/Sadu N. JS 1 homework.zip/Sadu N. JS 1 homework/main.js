let firstName = "Sadu";
let age = "28";
let city = "Astana";

let nameType = typeof(firstName);
let ageType = typeof(age);
let cityType = typeof(city);


console.log(firstName, age, city);
console.log(nameType, ageType,cityType);

let userAge = Number(prompt("Введите ваш возраст"));

console.log("Ваш возраст =", userAge, "года/лет");

let a = Number(prompt("Введите число a"));
let b = Number(prompt("Введите число b"));

let sum = (a + b);
let diff = (a - b);
let multiply = (a * b);
let divide = (a / b);

console.log("Сумма =", sum);
console.log("Разница =", diff);
console.log("Умножение =", multiply);
console.log("Деление =", divide);
